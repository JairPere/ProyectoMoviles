export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyAGi_3yUJvmrgEE39W2DGvNa6pUKSeKiU4",
  authDomain: "climaapps.firebaseapp.com",
  projectId: "climaapps",
  storageBucket: "climaapps.firebasestorage.app",
  messagingSenderId: "501241458768",
  appId: "1:501241458768:web:5c75d5692ceb0870052155",
  measurementId: "G-1F5636V8PM",
  vapidKey: "BCGQZikarWKBLXGt6aGBerQ2lDuQ9PiPDbVUtd4BTQHMQ6vSIyS13688hnrDDWcmsMk15RZjBtLM9AdFAYeR-Cs",
  },
   rapidApiKey: '6434d2d2d0msh056e013419ee164p1d61b0jsn08076e5c74be'
};