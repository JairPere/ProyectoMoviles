-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-11-2024 a las 18:31:18
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `software_store`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `stock`) VALUES
(1, 'Microsoft PowerPoint', 'Microsoft PowerPoint es una herramienta de software de presentación que forma parte del paquete de Microsoft Office. Se utiliza ampliamente en entornos educativos, empresariales y de investigación para crear presentaciones visuales de diapositivas. PowerPoint permite a los usuarios combinar texto, imágenes, gráficos, animaciones, videos y sonidos en presentaciones dinámicas y atractivas.', 50.00, 10),
(2, 'AnyDesk', 'AnyDesk es un software de acceso remoto que permite a los usuarios conectarse y controlar computadoras de manera remota a través de internet. A diferencia de otras soluciones de escritorio remoto, AnyDesk se distingue por su rendimiento excepcional, seguridad robusta y facilidad de uso, lo que lo convierte en una opción popular tanto para usuarios particulares como para empresas.', 75.00, 5),
(3, 'Microsoft Office 365', 'Paquete de productividad en la nube que incluye Word, Excel, PowerPoint, Outlook, OneDrive y Teams. Ideal para empresas y uso personal.', 99.99, 50),
(4, 'Adobe Photoshop', 'Software líder en edición de imágenes y gráficos. Herramientas avanzadas para la creación, retoque y manipulación de fotos.', 239.99, 30),
(5, 'Norton Antivirus', 'Protección completa contra virus, malware y amenazas en línea. Incluye firewall, protección en tiempo real y herramientas de privacidad.', 49.99, 100),
(6, 'AutoCAD', 'Software profesional de diseño asistido por computadora (CAD) para crear planos y modelos 2D y 3D en ingeniería, arquitectura y construcción.', 1499.99, 15),
(7, 'QuickBooks Pro', 'Software de contabilidad y gestión financiera para pequeñas y medianas empresas. Permite gestionar facturación, pagos, impuestos y más.', 199.99, 60),
(8, 'CorelDRAW Graphics Suite', 'Paquete completo para el diseño gráfico, que incluye herramientas avanzadas para ilustración, diseño de logotipos y edición de imágenes.', 499.99, 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `email`, `password`) VALUES
(1, 'Diego77605@hotmail.com', '$2y$10$HLKPbHwrclPfn46u0XFDdOXrmpyhmVRgWL9FvNK3dtuNQebzaUCoG'),
(8, 'Hugo@gmail.com', '$2y$10$nmRG8Gla7bt.397SNJQHTedUBLiHAzDOogHnYuIYot2LWDWe6/.qS');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
